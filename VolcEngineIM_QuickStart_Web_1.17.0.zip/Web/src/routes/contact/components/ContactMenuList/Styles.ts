import styled from 'styled-components';

export default styled.div`
  .list {
    height: calc(100vh - 70px);
  }
  .imat-badge-number.weak {
    background-color: #b2b8bc;
  }
`;

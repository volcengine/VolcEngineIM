import styled from 'styled-components';

export default styled.div`
  position: relative;
  height: 100%;
  overflow: hidden;
  background-color: transparent;
  will-change: transform;
`;

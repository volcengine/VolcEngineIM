import React, { FC } from 'react';

interface PinOptionBarProps {}

const PinOptionBar: FC<PinOptionBarProps> = props => {
  return <div></div>;
};

export default PinOptionBar;

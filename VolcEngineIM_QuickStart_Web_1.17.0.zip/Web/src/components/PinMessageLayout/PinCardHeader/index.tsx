import React, { FC } from 'react';

interface PinCardHeaderProps {}

const PinCardHeader: FC<PinCardHeaderProps> = props => {
  return <div className=""></div>;
};

export default PinCardHeader;

import styled from 'styled-components';

export default styled.div`
  overflow-y: auto;
  flex-grow: 1;
  .list {
    //height: calc(100vh - 70px);
  }
  .imat-badge-number.weak {
    background-color: #b2b8bc;
  }
`;

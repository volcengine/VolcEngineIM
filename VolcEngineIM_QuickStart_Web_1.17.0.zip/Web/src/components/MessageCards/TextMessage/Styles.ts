import { createGlobalStyle } from 'styled-components';

export const GlobalStyle = createGlobalStyle`
  .emoji-img {
    width: 30px;
    height: 30px;
  }
`;

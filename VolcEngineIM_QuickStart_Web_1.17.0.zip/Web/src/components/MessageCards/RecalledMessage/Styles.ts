import styled from 'styled-components';

export default styled.div`
  .unknown-message {
    padding: 10px 12px;
    font-size: 14px;
    line-height: 20px;
    color: #8f959e;
  }
`;

import styled from 'styled-components';

export default styled.div`
  max-width: 240px;
`;

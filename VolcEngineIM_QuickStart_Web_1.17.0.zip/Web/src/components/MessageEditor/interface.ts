export interface IRichText {
  // elementIds: string[];
  // elements: IRichTextElements;
  // imageIds: string[];
  // atIds: string[];
  // anchorIds: string[];
  // mediaIds: string[];
  // docsIds?: string[];
  // innerText: string;
  text: string;
}

# 火山引擎即时通讯 Web Demo 项目

详细说明请参见 https://www.volcengine.com/docs/6348/1009961

## 依赖安装
- `npm install`

## 前置配置
- 编辑 `src/constant/index.ts`，修改 `APP_ID` 为自己应用的值

## 运行项目
- `npm run start`
